#pragma once
#include <iostream>

class HealthComponent {
public:
    int maxHealth = 100;
    int currentHealth = 100;

    void TakeDamage(int amount) {
        currentHealth -= amount;
        if (currentHealth <= 0) {
            currentHealth = 0;
            std::cout << "💀 Entity died\n";
        } else {
            std::cout << "❤️ Health: " << currentHealth << "\n";
        }
    }
};

class Entity {
public:
    float x = 0, y = 0;
    HealthComponent health;

    void Move(float dx, float dy) {
        x += dx;
        y += dy;
        std::cout << "🚶 Entity moved to (" << x << ", " << y << ")\n";
    }

    void Update() {
        std::cout << "🔄 Updating entity at (" << x << ", " << y << ")\n";
    }

    void TakeHit(int damage) {
        std::cout << "💢 Entity hit for " << damage << " damage\n";
        health.TakeDamage(damage);
    }
};