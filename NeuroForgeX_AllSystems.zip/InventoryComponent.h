#pragma once
#include <vector>
#include <string>
#include <iostream>

class InventoryComponent {
    std::vector<std::string> items;

public:
    void AddItem(const std::string& item) {
        items.push_back(item);
        std::cout << "📦 Picked up: " << item << "\n";
    }

    void ShowInventory() {
        std::cout << "🎒 Inventory:\n";
        for (auto& item : items)
            std::cout << " - " << item << "\n";
    }
};