#pragma once
#include <iostream>

class InputSystem {
public:
    static void ProcessInput(char inputKey) {
        switch (inputKey) {
            case 'w': std::cout << "⬆️ Move Forward\n"; break;
            case 'a': std::cout << "⬅️ Move Left\n"; break;
            case 's': std::cout << "⬇️ Move Backward\n"; break;
            case 'd': std::cout << "➡️ Move Right\n"; break;
            case 'f': std::cout << "🔫 Fire Weapon\n"; break;
            default: std::cout << "❓ Unknown Input\n"; break;
        }
    }
};