#pragma once
#include <iostream>
#include "EntityManager.h"
#include "Bullet.h"
#include "AIComponent.h"

class Game {
    EntityManager manager;

public:
    void Run() {
        std::cout << "▶️ Game loop started.\n";

        Entity* player = manager.CreateEntity();
        Entity* enemy = manager.CreateEntity();
        AIComponent enemyAI(enemy, player);

        for (int i = 0; i < 7; i++) {
            std::cout << "\n🔄 Frame " << i + 1 << "\n";

            player->Move(1, 0);  // Player moves right

            if (i == 2 || i == 5) {
                Bullet b(enemy, 30);
                b.Fire();
            }

            enemyAI.UpdateAI();
            manager.UpdateAll();
        }

        std::cout << "\n🏁 Game loop ended.\n";
    }
};