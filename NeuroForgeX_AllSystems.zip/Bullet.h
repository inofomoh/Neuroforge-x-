#pragma once
#include <iostream>
#include "Entity.h"

class Bullet {
    Entity* target;
    int damage;

public:
    Bullet(Entity* _target, int _damage) : target(_target), damage(_damage) {}

    void Fire() {
        std::cout << "🔫 Bullet fired at enemy!\n";
        target->TakeHit(damage);
    }
};