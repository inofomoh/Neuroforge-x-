#include "Game.h"
#include "InputSystem.h"
#include "FlashlightSystem.h"
#include "VehicleComponent.h"
#include "InventoryComponent.h"
#include "CutsceneSystem.h"
#include "QuestSystem.h"
#include "WorldMap.h"
#include "MiniMapUI.h"

int main() {
    std::cout << "🔥 Starting NeuroForgeX Engine...\n";

    Game game;
    game.Run(); // Runs basic game loop with player, AI, bullets

    std::cout << "\n🎮 Running Input Demo:\n";
    InputSystem::ProcessInput('w');
    InputSystem::ProcessInput('f');

    std::cout << "\n🔦 Flashlight Demo:\n";
    FlashlightSystem flashlight;
    flashlight.Toggle();
    flashlight.Toggle();

    std::cout << "\n🚗 Vehicle Demo:\n";
    VehicleComponent vehicle;
    vehicle.Drive(10);
    vehicle.Brake();

    std::cout << "\n📦 Inventory Demo:\n";
    InventoryComponent inventory;
    inventory.AddItem("First Aid Kit");
    inventory.AddItem("Silver Key");
    inventory.ShowInventory();

    std::cout << "\n🎬 Cutscene Demo:\n";
    CutsceneSystem cutscenes;
    cutscenes.PlayCutscene("Intro Nightmare");

    std::cout << "\n🧠 Quest System Demo:\n";
    QuestSystem quests;
    quests.StartQuest("Find the Basement Key");
    quests.CompleteQuest("Find the Basement Key");

    std::cout << "\n🗺️ World Streaming Demo:\n";
    WorldMap map;
    map.LoadRegion("Foggy Town");
    map.LoadRegion("Abandoned Mansion");

    std::cout << "\n📍 Minimap Demo:\n";
    MiniMapUI minimap;
    minimap.ShowPosition(120.5f, 45.2f);

    std::cout << "\n✅ All systems running perfectly!\n";
    return 0;
}