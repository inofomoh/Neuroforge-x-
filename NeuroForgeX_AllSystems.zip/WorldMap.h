#pragma once
#include <iostream>

class WorldMap {
public:
    void LoadRegion(const std::string& name) {
        std::cout << "🗺️ Loading Region: " << name << "\n";
    }
};