#pragma once
#include <vector>
#include "Entity.h"

class EntityManager {
    std::vector<Entity*> entities;

public:
    Entity* CreateEntity() {
        Entity* entity = new Entity();
        entities.push_back(entity);
        return entity;
    }

    void UpdateAll() {
        for (Entity* e : entities)
            e->Update();
    }

    ~EntityManager() {
        for (Entity* e : entities)
            delete e;
    }
};