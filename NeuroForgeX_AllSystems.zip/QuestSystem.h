#pragma once
#include <iostream>

class QuestSystem {
public:
    void StartQuest(const std::string& questName) {
        std::cout << "🧭 Quest Started: " << questName << "\n";
    }

    void CompleteQuest(const std::string& questName) {
        std::cout << "✅ Quest Completed: " << questName << "\n";
    }
};