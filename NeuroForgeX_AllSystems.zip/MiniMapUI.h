#pragma once
#include <iostream>

class MiniMapUI {
public:
    void ShowPosition(float x, float y) {
        std::cout << "📍 You are at (" << x << ", " << y << ") on the minimap\n";
    }
};