#pragma once
#include <iostream>

class CutsceneSystem {
public:
    void PlayCutscene(const std::string& name) {
        std::cout << "🎬 Playing Cutscene: " << name << "\n";
    }
};