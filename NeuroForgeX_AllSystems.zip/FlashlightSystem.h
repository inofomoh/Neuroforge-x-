#pragma once
#include <iostream>

class FlashlightSystem {
    bool isOn = false;

public:
    void Toggle() {
        isOn = !isOn;
        std::cout << (isOn ? "🔦 Flashlight ON\n" : "🌑 Flashlight OFF\n");
    }
};