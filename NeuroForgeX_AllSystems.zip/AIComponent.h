#pragma once
#include <iostream>
#include "Entity.h"

class AIComponent {
    Entity* self;
    Entity* target;
    int attackCooldown = 0;

public:
    AIComponent(Entity* _self, Entity* _target) : self(_self), target(_target) {}

    void UpdateAI() {
        if (self->health.currentHealth <= 0) return;

        float dx = target->x - self->x;
        float dy = target->y - self->y;

        if (dx != 0 || dy != 0) {
            float stepX = (dx > 0) ? 1 : -1;
            float stepY = (dy > 0) ? 1 : -1;
            self->Move(stepX * 0.5f, stepY * 0.5f);
        }

        if (abs(dx) < 1.5f && abs(dy) < 1.5f && attackCooldown == 0) {
            std::cout << "😈 AI attacks Player!\n";
            target->TakeHit(20);
            attackCooldown = 2;
        }

        if (attackCooldown > 0)
            attackCooldown--;
    }
};