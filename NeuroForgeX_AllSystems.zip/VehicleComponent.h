#pragma once
#include <iostream>

class VehicleComponent {
public:
    float speed = 0;
    void Drive(float throttle) {
        speed += throttle * 0.5f;
        std::cout << "🚗 Driving... Speed: " << speed << " km/h\n";
    }

    void Brake() {
        speed *= 0.5f;
        std::cout << "🛑 Braking... Speed: " << speed << " km/h\n";
    }
};